#pragma once
#include "SharedAlgorithm.h"
class _203246509_B :
	public SharedAlgorithm
{

public:
	virtual Direction step() override;

};