#ifndef _203246509_A_H_
#define _203246509_A_H_

#include "SharedAlgorithm.h"
#include "OurSensor.h"
using namespace std;

class _203246509_A :
	public SharedAlgorithm
{



public:

	virtual Direction step() override;




};

#endif /* _203246509_A_H_ */
